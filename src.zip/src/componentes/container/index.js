import React from 'react';
import './styles.css'
import Lista from '../lista/index.js'

  class Container extends React.Component {



    render() {  
        return (
            <div className="container">
              <div className="main_contant">
                <Lista/>
              </div>
            </div>
        );

    }
  }

  export default Container;